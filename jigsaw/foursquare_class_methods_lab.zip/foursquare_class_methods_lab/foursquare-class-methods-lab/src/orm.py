def build_from_record(Class, record):
    if not record: return None

    attr = dict(zip(Class.columns, record))
    obj = Class()
    obj.__dict__ = attr
    return obj

# return a record by it's primary key
# def find_by_id(id, Class, cursor):
#     query = f"SELECT * FROM {Class.__table__} where id = %s"
#     print(id, Class, cursor)
#     cursor.execute(query, (id,))
#     record = cursor.fetchone()
#     category = build_from_record(Class, record)
#     breakpoint()
#     return category

@classmethod
def find_by_id(cls, id, cursor):
    query = f"SELECT * FROM {cls.__table__} WHERE id = %s"
    cursor.execute(query, (id,))
    record = cursor.fetchone()
    if record:
        return build_from_record(cls, record)
    else:
        return None

def find_all(Class, cursor):
    sql_str = f"SELECT * FROM {Class.__table__}"
    cursor.execute(sql_str)
    records = cursor.fetchall()
    return [build_from_record(Class, record) for record in records]

def values(obj):
    venue_attrs = obj.__dict__
    return [venue_attrs[attr] for attr in obj.columns if attr in venue_attrs.keys()]

def keys(obj):
    venue_attrs = obj.__dict__
    selected = [attr for attr in obj.columns if attr in venue_attrs.keys()]
    return ', '.join(selected)


def save(obj, conn, cursor):
    s_str = ', '.join(len(values(obj)) * ['%s'])
    venue_str = f"""INSERT INTO {obj.__table__} ({keys(obj)}) VALUES ({s_str});"""
    cursor.execute(venue_str, list(values(obj)))
    conn.commit()
